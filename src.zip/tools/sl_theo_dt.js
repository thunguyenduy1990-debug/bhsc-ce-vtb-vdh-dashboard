#!/usr/bin/env node
/* sl_theo_dt.js — tính lại SẢN LƯỢNG BÊN TRONG thực đạt theo DOANH THU đã chốt.
   Dùng:  node src/tools/sl_theo_dt.js <db.json> <kỳ> [--le]
   Quy tắc: SL thực = doanh thu bên trong thực / đơn giá gốc (dt.trong.dgiaNguon, GIỮ NGUYÊN).
   Mặc định làm tròn số nguyên; cập nhật kèm sl.act, sl.tongTatCa. Không đụng mục khác. */
const fs=require('fs');
const [,,f,ky,...rest]=process.argv;
if(!f||!ky){ console.error('Dùng: node src/tools/sl_theo_dt.js <db.json> <kỳ> [--le]'); process.exit(1); }
const le=rest.includes('--le');
const db=JSON.parse(fs.readFileSync(f,'utf8')); const K=db.ky[ky];
if(!K){ console.error('Không có kỳ',ky); process.exit(1); }
const bang=[];
const sua=(ten,u)=>{
  if(!u||!u.sl||!u.sl.cats||!u.sl.cats.trong||!u.dt||!u.dt.trong) return;
  const dt=u.dt.trong.act, dg=u.dt.trong.dgiaNguon;
  if(typeof dt!=='number'||typeof dg!=='number'||!dg) return;
  const cu=u.sl.cats.trong.act, moi=le?dt/dg:Math.round(dt/dg);
  u.sl.cats.trong.act=moi; if(typeof u.sl.act==='number') u.sl.act=moi;
  const C=Object.values(u.sl.cats);
  const A=C.filter(o=>typeof o.act==='number').map(o=>o.act), T=C.filter(o=>typeof o.target==='number').map(o=>o.target);
  u.sl.tongTatCa={target:T.length?T.reduce((a,b)=>a+b,0):null, act:A.length?A.reduce((a,b)=>a+b,0):null};
  bang.push([ten,cu,moi,dt,dg]);
};
for(const [ma,t] of Object.entries(K.tinh)){ sua(t.ten||ma,t); if(t.kho) sua((t.ten||ma)+' (kho)',t.kho); }
fs.writeFileSync(f,JSON.stringify(db),'utf8');
const fm=x=>x.toLocaleString('vi-VN',{maximumFractionDigits:le?2:0});
console.log(`${ky} — tính lại SẢN LƯỢNG BÊN TRONG theo doanh thu (${bang.length} đơn vị)\n`);
console.log('  '+'Đơn vị'.padEnd(20)+'SL file'.padStart(9)+'SL mới'.padStart(9)+'Chênh'.padStart(9)+'Doanh thu'.padStart(16)+'Đơn giá'.padStart(10));
let a=0,b=0;
for(const [t,cu,m,dt,dg] of bang){ a+=cu;b+=m;
  console.log('  '+String(t).slice(0,20).padEnd(20)+fm(cu).padStart(9)+fm(m).padStart(9)+((m-cu>0?'+':'')+fm(m-cu)).padStart(9)+fm(dt).padStart(16)+fm(dg).padStart(10)); }
console.log('  '+'TỔNG'.padEnd(20)+fm(a).padStart(9)+fm(b).padStart(9)+((b-a>0?'+':'')+fm(b-a)).padStart(9));
