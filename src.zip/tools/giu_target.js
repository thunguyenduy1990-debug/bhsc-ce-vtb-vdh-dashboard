#!/usr/bin/env node
/* giu_target.js — GIỮ target đã chốt khi file nguồn mang sheet TARGET CŨ.
   (15/11/2026: file "File Data cập nhật Web" dựng từ mẫu cũ -> TARGET trước 07/11, mất khối C VT)
   Dùng: node src/tools/giu_target.js <db.json> <data.json đang chạy> <kỳ...>
   · DB.targetDT[kỳ] := bản đang chạy (base 07/11 + khối VT)
   · áp lại đúng quy tắc của import (xoApTargetBase): target 4 nhóm = sheet TARGET,
     targetGoc = SL target × ĐG target, targetVT khách lẻ = VT, gói bán = 0            */
const fs=require('fs');
const [,,f,live,...kys]=process.argv;
if(!f||!live||!kys.length){ console.error('Dùng: node src/tools/giu_target.js <db.json> <live.json> <kỳ...>'); process.exit(1); }
const db=JSON.parse(fs.readFileSync(f,'utf8')), L=JSON.parse(fs.readFileSync(live,'utf8'));
const NB=v=>(typeof v==='number'&&isFinite(v))?v:null, NHOM=['trong','doi1','bhmr','sckl'];
const tr=x=>(x/1e6).toLocaleString('vi-VN',{maximumFractionDigits:0});
for(const key of kys){
  const K=db.ky[key], T=(L.targetDT||{})[key];
  if(!K||!T){ console.error('thiếu kỳ / targetDT bản đang chạy:',key); process.exit(2); }
  const truoc=JSON.stringify(db.targetDT[key]||{}).length;
  db.targetDT[key]=JSON.parse(JSON.stringify(T));
  const s={trong:0,doi1:0,bhmr:0,sckl:0,vt:0}; let nvt=0;
  for(const ma in K.tinh){ const t=K.tinh[ma];
    [[t,T[ma]],[t&&t.kho,(T[ma]||{}).kho]].forEach(([u,tg])=>{
      if(!u||!u.dt||!tg) return;
      NHOM.forEach(c=>{ const o=u.dt[c]; if(!o) return;
        const sl=u.sl&&u.sl.cats&&u.sl.cats[c], dg=u.dgia&&u.dgia.cats&&u.dgia.cats[c];
        const goc=(sl&&dg&&NB(sl.target)!=null&&NB(dg.target)!=null)?sl.target*dg.target:NB(o.target);
        if(goc!=null) o.targetGoc=goc;
        if(NB(tg[c])!=null) o.target=tg[c]; s[c]+=o.target||0; });
      if(u.dt.sckl&&tg.vt&&NB(tg.vt.sckl)!=null){ u.dt.sckl.targetVT=tg.vt.sckl; }
      if(tg.vt) nvt++;
      if(u.dt.goi){ u.dt.goi.target=0; u.dt.goi.act=0; if('actDH' in u.dt.goi) u.dt.goi.actDH=0; if('actKeHoach' in u.dt.goi) u.dt.goi.actKeHoach=0; }
      const C=u.sl&&u.sl.cats;
      if(C&&C.goi){ C.goi.target=0; C.goi.act=0; if('actKeHoach' in C.goi) C.goi.actKeHoach=0;
        const A=Object.values(C).filter(o=>NB(o.act)!=null).map(o=>o.act), TT=Object.values(C).filter(o=>NB(o.target)!=null).map(o=>o.target);
        u.sl.tongTatCa={target:TT.length?TT.reduce((a,b)=>a+b,0):null, act:A.length?A.reduce((a,b)=>a+b,0):null}; }
    }); }
  console.log(`${key}: giữ target đang chạy — bên trong ${tr(s.trong)} · 1đ1 ${tr(s.doi1)} · BHMR ${tr(s.bhmr)} · khách lẻ ${tr(s.sckl)} tr · ${nvt} đơn vị có VT`);
}
fs.writeFileSync(f,JSON.stringify(db),'utf8');
