#!/usr/bin/env bash
# cap_nhat.sh — quy trình chuẩn mỗi lần anh Thu gửi file KHO DỮ LIỆU.
# Dùng: bash src/tools/cap_nhat.sh <file.xlsx> <data.json đang chạy> "<kỳ:ngày ...>" "<kỳ SL theo DT ...>"
#   vd: bash src/tools/cap_nhat.sh mau_nhap/X.xlsx live.json "2026-10:31 2026-11:7" "2026-10 2026-11"
# Quy tắc T10–T12/2026 (target base theo sheet TARGET, gói bán = 0, VT) nằm SẴN trong import của web.
set -euo pipefail
cd "$(dirname "$0")/../.."
X="$1"; LIVE="$2"; MOC="$3"; SLDT="${4:-}"
node src/assemble.js | tail -1
node src/build.js src/_live_db.json > /dev/null          # index.html mới (mã) — dữ liệu nạp ở bước sau
cp "$LIVE" github/data.json                               # nền = data.json ĐANG CHẠY (giữ mốc, 2027, sửa tay…)
node src/tools/nap_kho.js "$X" | tail -2
for km in $MOC; do node src/tools/luy_ke.js src/db.json "${km%%:*}" "${km##*:}" --khong-quy-doi | tail -1; done
for k in $SLDT; do node src/tools/sl_theo_dt.js src/db.json "$k" | tail -1; done
node src/build.js src/db.json | tail -2
