
/* =============================================================================
   MODULE 10 — TARGET VƯỢT TRỘI DOANH THU  (tab 11)          — dựng 08/11/2026
   Khác hẳn tab 10 (VƯỢT TRỘI nhân viên). Đo DOANH THU từng tỉnh/kho so với 2 mức:
     · TARGET BASE  = target doanh thu đang chấm trên web (sheet TARGET, khối A/B)
     · TARGET VƯỢT TRỘI (VT) = khối C sheet TARGET: DB.targetDT[kỳ][mã](.kho).vt
   4 nhóm: Bên trong · 1 Đổi 1 · Bảo hành mở rộng · Khách lẻ (SCDV) + TỔNG (1+2+3+4).
   3 mức đánh giá: ĐẠT VƯỢT TRỘI (≥ VT) · ĐẠT BASE (≥ base, < VT) · CHƯA ĐẠT BASE.

   CÁCH CHẤM (thống nhất cho 1 tháng và cộng dồn nhiều tháng, vd Q4):
     tỷ lệ = THỰC ĐẠT cộng dồn ÷ TARGET "tới hiện tại"
     target tới hiện tại = Σ target tháng × phần tháng đã qua
       (tháng đã chốt = 1 · tháng đang chạy = ngày đã qua/ngày trong tháng · tháng chưa có số = 0)
   => 1 tháng đang chạy: đúng bằng DỰ KIẾN CẢ THÁNG ÷ TARGET như các tab khác.
   Chỉ hiện trên web + Excel (khối C sheet TARGET); KHÔNG đưa vào PPT.
   ============================================================================= */
const VTD_NHOM=[
  {k:"trong", ten:"BÊN TRONG",        sub:"BH tại nhà & tại kho", icon:"layers",  cat:l=>l==="kho"?"Bảo hành tại kho":"Bảo hành tại nhà", kho:true},
  {k:"doi1",  ten:"1 ĐỔI 1",          sub:"bảo hành 1 đổi 1",     icon:"refresh", cat:()=>"BH 1 đổi 1", kho:false},
  {k:"bhmr",  ten:"BẢO HÀNH MỞ RỘNG", sub:"BHMR",                 icon:"shield",  cat:()=>"BHMR",       kho:false},
  {k:"sckl",  ten:"KHÁCH LẺ (SCDV)",  sub:"sửa chữa khách lẻ",    icon:"wrench",  cat:()=>"SCDV",       kho:true}
];
const VTD_TONG={k:"tong", ten:"TỔNG VƯỢT TRỘI", sub:"1 + 2 + 3 + 4", icon:"trophy"};
let VTD_SEL="tong";                                   // nhóm đang xem ở bảng chi tiết

const vtdT=(nam,m)=>(DB.targetDT||{})[kyKey(nam,m)];
function vtdCoVT(nam,m){ const T=vtdT(nam,m); if(!T) return false;
  return Object.values(T).some(u=>u&&((u.vt&&Object.keys(u.vt).length)||(u.kho&&u.kho.vt))); }
function vtdThangVT(nam){ return [...Array(12)].map((_,i)=>i+1).filter(m=>vtdCoVT(nam,m)); }
/* tháng đã có số thực đạt doanh thu (tháng chưa có số -> không tính vào nhịp) */
/* ngưỡng 1 triệu đồng tổng toàn vùng: bỏ qua số lẻ rác do công thức của file nguồn (vd 0,07đ) */
function vtdCoSo(nam,m){ const D=DB.ky[kyKey(nam,m)]; if(!D||!D.tinh) return false;
  let s=0; Object.values(D.tinh).forEach(r=>{ for(const u of [r,r&&r.kho]){ const x=u&&u.dt&&u.dt.trong;
    if(x&&NB(x.act)>0) s+=x.act; } }); return s>=1e6; }
function vtdVT(nam,m,code,loai,k){ const T=vtdT(nam,m); let u=T&&T[code]; if(u&&loai==="kho") u=u.kho;
  return u&&u.vt?TRI(u.vt[k]):null; }
/* đơn vị trong phạm vi lọc cho 1 nhóm */
function vtdUnits(n,S){
  const out=[];
  if(showNha(S)) unitsNha(S).forEach(c=>out.push([c,"nha"]));
  if(showKho(S)&&(n.k==="tong"||n.kho)) unitsKho(S).forEach(c=>out.push([c,"kho"]));
  return out;
}
/* 1 đơn vị × 1 nhóm × các tháng đang xem */
function vtdO(){ return {A:0,nA:0,BF:0,VF:0,BN:0,VN:0,nB:0,nV:0,dk:null}; }
function vtdCell(code,loai,n,months,S){
  const o=vtdO();
  if(n.k==="tong"){ VTD_NHOM.filter(g=>loai!=="kho"||g.kho).forEach(g=>vtdCong(o,vtdCell(code,loai,g,months,S))); return vtdXong(o,months,S); }
  if(loai==="kho"&&!n.kho) return null;                                  // kho không có 1Đ1 / BHMR
  for(const m of months){
    const S1=Object.assign({},S,{ky:"Tháng",thang:m,months:[m]});
    const k=calcDtUnitCat(code,loai,n.cat(loai),S1);
    const vt=vtdVT(S.nam,m,code,loai,n.k), co=vtdCoSo(S.nam,m);
    const e=co?((k.meta&&k.meta.prorate)||1):0;
    if(co&&k.actual!=null){ o.A+=k.actual; o.nA++; }
    if(k.target!=null){ o.BF+=k.target; o.BN+=k.target*e; o.nB++; }
    if(vt!=null){ o.VF+=vt; o.VN+=vt*e; o.nV++; }
  }
  return vtdXong(o,months,S);
}
function vtdCong(o,x){ if(!x) return; if(x.A!=null){o.A+=x.A;o.nA++;} if(x.BF!=null){o.BF+=x.BF;o.BN+=x.BN;o.nB++;}
  if(x.VF!=null){o.VF+=x.VF;o.VN+=x.VN;o.nV++;} }
function vtdXong(o,months,S){
  const A=o.nA?o.A:null, BF=o.nB?o.BF:null, VF=o.nV?o.VF:null;
  const r={A, BF, VF, BN:o.BN, VN:o.VN,
    rB:(A!=null&&o.BN>0)?A/o.BN:null, rV:(A!=null&&o.VN>0)?A/o.VN:null,
    pB:(A!=null&&BF)?A/BF:null,       pV:(A!=null&&VF)?A/VF:null,
    thieu:(A!=null&&VF!=null)?Math.max(0,VF-A):null};
  /* 1 tháng đang chạy: dự kiến cả tháng (để hiện cạnh thực đạt) */
  if(months.length===1&&A!=null&&o.VN>0&&VF&&o.VN<VF-1e-9) r.dk=A/(o.VN/VF);
  else if(months.length===1&&A!=null&&o.BN>0&&BF&&o.BN<BF-1e-9) r.dk=A/(o.BN/BF);
  r.muc = A==null ? "none" : (r.rV!=null&&r.rV>=1) ? "vt" : (r.rB!=null&&r.rB>=1) ? "bs" : "no";
  return r;
}
const VTD_MUC={vt:{t:"ĐẠT VƯỢT TRỘI",i:"trophy"}, bs:{t:"ĐẠT BASE",i:"check"}, no:{t:"CHƯA ĐẠT BASE",i:"x"}, none:{t:"CHƯA CÓ SỐ",i:"minus"}};
function vtdBadge(x){ const m=VTD_MUC[x?x.muc:"none"]; return `<span class="vtdb ${x?x.muc:"none"}">${ic(m.i,10)}${m.t}</span>`; }
const vtdPc=v=>v==null?DASH:pc1(v);
function vtdTip(x,n,lbl){
  if(!x||x.A==null) return "";
  return tipAttr(`<div class="tt">${ic(n.icon||"trophy",12)}${esc(n.ten)} · ${esc(lbl)}</div>
    <dl><dt>Thực đạt</dt><dd>${tr(x.A)}</dd>${x.dk!=null?`<dt>Dự kiến cả tháng</dt><dd>${tr(x.dk)}</dd>`:""}
    <dt>Target base</dt><dd>${tr(x.BF)}</dd><dt>Target vượt trội</dt><dd>${tr(x.VF)}</dd>
    ${(x.BN&&x.BF&&x.BN<x.BF-1e-6)?`<dt>Base tới hiện tại</dt><dd>${tr(x.BN)}</dd><dt>VT tới hiện tại</dt><dd>${tr(x.VN)}</dd>`:""}
    <dt>% so base</dt><dd>${vtdPc(x.rB)}</dd><dt>% so vượt trội</dt><dd>${vtdPc(x.rV)}</dd>
    <dt>Còn thiếu tới VT</dt><dd>${x.thieu==null?"–":x.thieu<=0?"đã chạm":tr(x.thieu)}</dd></dl>`);
}

function renderM10(){
  const S=ST, nam=S.nam, coVT=vtdThangVT(nam);
  if(!coVT.length) return emptyCard("Chưa có Target Vượt Trội",
    `Năm ${nam} chưa có khối <b>C. TARGET VƯỢT TRỘI</b> trong sheet TARGET của file dữ liệu.`);
  /* tháng đang xem = các tháng đã chọn có VT; nếu bộ lọc chung đang ở tháng khác
     thì tự hiện THÁNG GẦN NHẤT có số (không đổi bộ lọc chung) và nói rõ.         */
  let ms=(S.ky==="Năm"?coVT:selMonths(S)).filter(m=>coVT.indexOf(m)>=0), tuChon=false;
  if(!ms.length){ const cs=coVT.filter(m=>vtdCoSo(nam,m)); ms=[cs.length?cs[cs.length-1]:coVT[0]]; tuChon=true; }
  const SS=Object.assign({},S,{ky:"Tháng",thang:ms[ms.length-1],months:ms});
  const quy=ms.length>1;
  const lblKy = quy ? `Cộng dồn ${monthsLabel(ms)}/${nam}` : (()=>{ const D=DB.ky[kyKey(nam,ms[0])];
      return D&&isLuyKe(D)?`Lũy kế T${ms[0]}/${nam} (${D.ngayDaQua}/${D.ngayTrongThang} ngày)`:`Cả tháng ${ms[0]}/${nam}`; })();
  const nhoms=[VTD_TONG].concat(VTD_NHOM);
  const tongOf=n=>{ const o=vtdO(); vtdUnits(n,SS).forEach(([c,l])=>vtdCong(o,vtdCell(c,l,n,ms,SS))); return vtdXong(o,ms,SS); };
  const T=nhoms.map(n=>({n,x:tongOf(n)}));
  const tg=T[0].x;
  if(!nhoms.some(n=>n.k===VTD_SEL)) VTD_SEL="tong";

  /* ---- chọn kỳ ngay trong tab (đổi bộ lọc tháng chung của trang) ---- */
  const chip=(id,txt,arr)=>{ const on=arr.length===ms.length&&arr.every((m,i)=>m===ms[i])&&!(tuChon&&arr.length===1);
    const co=arr.some(m=>vtdCoSo(nam,m));
    return `<button type="button" class="vtdk${on?" on":""}${co?"":" nod"}" data-vtdky="${arr.join(",")}"
      title="${esc(txt)}${co?"":" — chưa có số thực đạt"}">${esc(txt)}</button>`; };
  const chips=coVT.map(m=>chip("t"+m,"T"+m,[m])).join("")
    + (coVT.length>1?chip("q",`Cộng dồn ${monthsLabel(coVT)}`,coVT):"");

  const banner=bannerHTML("TARGET VƯỢT TRỘI — DOANH THU","trophy",[
    bItem("Thực đạt (4 nhóm)","banknote",tg.A==null?"–":tr(tg.A),"",
      quy?`${ms.length} tháng cộng dồn`:(tg.dk!=null?`dự kiến cả tháng <b style="color:#FFD500">${tr(tg.dk)}</b>`:"cả tháng"),true),
    bItem("Target vượt trội","trophy",tr(tg.VF),"",`% đạt <b style="color:#FFD500">${vtdPc(tg.rV)}</b>`),
    bItem("Target base","target",tr(tg.BF),"",`% đạt <b style="color:#FFD500">${vtdPc(tg.rB)}</b>`),
    bItem("Còn thiếu tới VT","flame",tg.thieu==null?"–":tg.thieu<=0?"đã chạm":tr(tg.thieu),"",quy?`so tổng VT ${ms.length} tháng`:"so VT cả tháng"),
    bItem("Đơn vị đạt VT","medal",(()=>{ const us=vtdUnits(VTD_TONG,SS); const n=us.filter(([c,l])=>{const x=vtdCell(c,l,VTD_TONG,ms,SS);return x&&x.muc==="vt"}).length;
      return `${n}<span class="u">/${us.length}</span>`; })(),"","tổng 4 nhóm")
  ]);

  const kyBar=`<div class="vtdbar"><div class="vtdbar-l">${ic("calendar",14)}<b>Kỳ đo:</b> ${esc(lblKy)}
      ${tuChon?`<span class="vtdnote">Bộ lọc tháng chung đang ở ${esc(kyLabel(S))} — Target Vượt Trội chỉ có ${esc(monthsLabel(coVT))}/${nam} nên đang hiện tháng gần nhất có số.</span>`:""}</div>
    <div class="vtdbar-r">${chips}</div></div>`;

  /* ---- 5 thẻ: tổng + 4 nhóm; bấm để chọn nhóm cho bảng chi tiết ---- */
  const cards=`<div class="vtdcards">${T.map(({n,x})=>{
    const w=x.rV==null?0:clamp(x.rV*100,2,100);
    return `<button type="button" class="vtdcard m-${x.muc}${VTD_SEL===n.k?" sel":""}" data-vtdnhom="${n.k}" ${vtdTip(x,n,lblKy)}>
      <span class="vh">${ic(n.icon,15)}<b>${esc(n.ten)}</b></span>
      <span class="vs">${esc(n.sub)}</span>
      <span class="vv">${vtdPc(x.rV)}<small> so VT</small></span>
      <span class="vm"><i style="width:${w}%"></i></span>
      <span class="vf">${vtdBadge(x)}<span>base ${vtdPc(x.rB)}</span></span>
      <span class="vn">Thực đạt <b>${x.A==null?"–":tr(x.A)}</b> · VT <b>${tr(x.VF)}</b></span></button>`; }).join("")}</div>`;

  /* ---- bảng chi tiết nhóm đang chọn ---- */
  const nSel=nhoms.find(n=>n.k===VTD_SEL);
  const us=vtdUnits(nSel,SS);
  const rows=us.map(([c,l])=>({c,l,x:vtdCell(c,l,nSel,ms,SS)})).filter(r=>r.x);
  const tSel=T.find(t=>t.n.k===VTD_SEL).x;
  const td=(x)=>`<td class="num">${x.A==null?DASH:tr(x.A)}${x.dk!=null?`<i class="vtddk">dự kiến ${tr(x.dk)}</i>`:""}</td>
      <td>${tr(x.BF)}</td><td class="vtdvt">${tr(x.VF)}</td>
      <td class="r-${x.rB==null?"none":x.rB>=1?"ok":"no"}">${vtdPc(x.rB)}</td>
      <td class="r-${x.muc}"><b>${vtdPc(x.rV)}</b>${quy&&x.pV!=null?`<i class="vtddk">hoàn thành ${vtdPc(x.pV)} VT cả kỳ</i>`:(x.dk!=null&&x.pV!=null?`<i class="vtddk">đến hiện tại ${vtdPc(x.pV)} VT</i>`:"")}</td>
      <td>${x.thieu==null?DASH:x.thieu<=0?`<span class="vtdok">đã chạm</span>`:tr(x.thieu)}</td>
      <td>${vtdBadge(x)}</td>`;
  const bang=`<div class="card"><header><span class="ci">${ic(nSel.icon,16)}</span>
      <div><h3>${esc(nSel.ten)} — chi tiết theo tỉnh / kho</h3><span class="sub">${esc(lblKy)} · ${esc(scopeLbl(S))} · bấm thẻ phía trên để đổi nhóm</span></div>
      <div class="hr">${infoI(`<b>% so base / % so VT</b> = thực đạt ÷ target <b>tới hiện tại</b>.
        Tháng đã chốt tính đủ tháng; tháng đang chạy nhân target với số ngày đã qua (với 1 tháng thì đúng bằng
        <b>dự kiến cả tháng ÷ target</b> như các tab khác); tháng chưa có số không tính.
        <b>Còn thiếu tới VT</b> = target vượt trội cả kỳ − thực đạt đã có.`)}</div></header>
    <div class="body tight"><div class="tblwrap"><table class="dt vtdtbl">
      <thead><tr><th class="l stick">VÙNG</th><th class="l stick2">TỈNH / KHO</th>
        <th>THỰC ĐẠT</th><th>TARGET BASE</th><th class="vtdvt">TARGET VƯỢT TRỘI</th>
        <th>% SO BASE</th><th>% SO VƯỢT TRỘI</th><th>CÒN THIẾU TỚI VT</th><th>ĐÁNH GIÁ</th></tr></thead>
      <tbody><tr class="tot"><td class="l stick">${esc(S.vung==="TONG"?"2 vùng":S.vung)}</td><td class="l stick2">TỔNG:</td>${td(tSel)}</tr>
        ${rows.map(r=>`<tr ${vtdTip(r.x,nSel,(r.l==="kho"?tinhOf(r.c)+" (kho)":tinhOf(r.c)))}>
          <td class="l stick">${esc(vungOf(r.c).replace("Vùng ","V. "))}</td>
          <td class="l stick2"><b>${esc(tinhOf(r.c))}</b>${r.l==="kho"?` <span class="vtag kho">kho</span>`:""}</td>${td(r.x)}</tr>`).join("")}
      </tbody></table></div>
      <div class="cap">Kho bảo hành tại kho chỉ có nhóm <b>Bên trong</b> và <b>Khách lẻ</b> (không có 1 Đổi 1 / BHMR).
        Target vượt trội nhóm <b>Bên trong</b> bằng đúng target base (theo sheet TARGET) nên đạt base là đạt vượt trội.</div>
    </div></div>`;

  /* ---- ma trận % so VT: đơn vị × nhóm ---- */
  const usAll=vtdUnits(VTD_TONG,SS);
  const mt=`<div class="card"><header><span class="ci">${ic("grid",16)}</span>
      <div><h3>Toàn cảnh % đạt Target Vượt Trội</h3><span class="sub">${esc(lblKy)} · mỗi ô = % so VT · màu theo 3 mức đánh giá</span></div></header>
    <div class="body tight"><div class="tblwrap"><table class="dt vtdmx">
      <thead><tr><th class="l stick">VÙNG</th><th class="l stick2">TỈNH / KHO</th>${nhoms.map(n=>`<th>${esc(n.ten)}</th>`).join("")}</tr></thead>
      <tbody><tr class="tot"><td class="l stick">${esc(S.vung==="TONG"?"2 vùng":S.vung)}</td><td class="l stick2">TỔNG:</td>
        ${T.map(({n,x})=>`<td class="r-${x.muc}" ${vtdTip(x,n,"tổng")}><b>${vtdPc(x.rV)}</b></td>`).join("")}</tr>
      ${usAll.map(([c,l])=>`<tr><td class="l stick">${esc(vungOf(c).replace("Vùng ","V. "))}</td>
        <td class="l stick2"><b>${esc(tinhOf(c))}</b>${l==="kho"?` <span class="vtag kho">kho</span>`:""}</td>
        ${nhoms.map(n=>{ const x=vtdCell(c,l,n,ms,SS); if(!x) return `<td class="vtdna">–</td>`;
          return `<td class="r-${x.muc}" ${vtdTip(x,n,l==="kho"?tinhOf(c)+" (kho)":tinhOf(c))}><b>${vtdPc(x.rV)}</b></td>`; }).join("")}</tr>`).join("")}
      </tbody></table></div>
      <div class="vtdleg"><span class="vtdb vt">${ic("trophy",10)}ĐẠT VƯỢT TRỘI</span> ≥ 100% target vượt trội
        <span class="vtdb bs">${ic("check",10)}ĐẠT BASE</span> ≥ 100% base nhưng chưa tới VT
        <span class="vtdb no">${ic("x",10)}CHƯA ĐẠT BASE</span> &lt; 100% base</div>
    </div></div>`;

  return banner+kyBar+cards+bang+mt;
}

/* sự kiện: chọn kỳ / chọn nhóm */
document.addEventListener("click",e=>{
  if(ST.tab!==10) return;
  const k=e.target.closest("[data-vtdky]");
  if(k){ const ms=k.dataset.vtdky.split(",").map(Number); ST.ky="Tháng"; setMonths(ms); return; }
  const n=e.target.closest("[data-vtdnhom]");
  if(n){ VTD_SEL=n.dataset.vtdnhom; render(); }
});
