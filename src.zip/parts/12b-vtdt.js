
/* =============================================================================
   MODULE 10 — TARGET VƯỢT TRỘI DOANH THU  (tab 11)        — làm lại 08/11/2026
   Theo yêu cầu anh Thu: GIỐNG TAB 5 DOANH THU (chỉ phần bảng), cột KPI thay bằng
   TARGET VƯỢT TRỘI (khối C sheet TARGET -> DB.targetDT[kỳ][mã](.kho).vt).
   Thực đạt, quy đổi lũy kế, chấm ĐẠT/KHÔNG ĐẠT y hệt tab 5 — chỉ khác target.
   4 nhóm có VT: Bên trong (nhà + kho) · 1 Đổi 1 · BHMR · Khách lẻ (SCDV).
   Gói bán 2025 và 5 dịch vụ mới KHÔNG có VT nên không có trong tab này.
   Nhiều tháng: chỉ cộng các tháng CÓ target VT (target + thực đạt cùng các tháng đó).
   Khác hẳn tab 10 (VƯỢT TRỘI nhân viên). Không đưa vào PPT.
   ============================================================================= */
const VTD_ICON={"Bảo hành tại nhà":"home","Bảo hành tại kho":"warehouse","BH 1 đổi 1":"refresh","BHMR":"shield","SCDV":"wrench"};
function vtdVT(nam,m,code,loai,fld){ const T=(DB.targetDT||{})[kyKey(nam,m)]; let u=T&&T[code]; if(u&&loai==="kho") u=u.kho;
  return u&&u.vt?TRI(u.vt[fld]):null; }
function vtdThangVT(nam){ return [...Array(12)].map((_,i)=>i+1).filter(m=>{ const T=(DB.targetDT||{})[kyKey(nam,m)];
  return !!T&&Object.values(T).some(u=>u&&(u.vt||(u.kho&&u.kho.vt))); }); }
/* 1 đơn vị × 1 nhóm doanh thu — cùng thực đạt với tab 5, target = VT */
function calcVtdUnitCat(code,loai,cat,S=ST){
  const base={key:"vt:"+cat,name:DT_LABEL[cat]||cat,icon:VTD_ICON[cat]||"banknote",fmt:tr,unit:"tr đ"};
  if(isYear(S)){
    let t=0,a=0,n=0,nM=0,nNA=0;
    eachMonth(S,(Dm,S2)=>{ const k=calcVtdUnitCat(code,loai,cat,S2);
      if(k.naLabel==="không áp dụng"){nNA++;return;}
      if(k.target==null) return;                                   // tháng không có VT: bỏ cả thực đạt
      nM++; t+=k.target; if(k.actual!=null){a+=k.actual;n++;} });
    if(nNA&&!nM) return mkKpi(Object.assign({},base,{target:null,actual:null,naLabel:"không áp dụng",
      dataReason:"Nghiệp vụ này không phát sinh ở đơn vị đang xem"}));
    if(!nM) return mkKpi(Object.assign({},base,{target:null,actual:null,naLabel:"chưa có target vượt trội",
      dataReason:"Các tháng đang chọn chưa có Target Vượt Trội"}));
    return mkKpi(Object.assign({},base,{target:t,actual:n?a:null,meta:{congDon:true,soThangVT:nM}}));
  }
  const b=calcDtUnitCat(code,loai,cat,S);
  if(b.naLabel==="không áp dụng") return mkKpi(Object.assign({},base,{target:null,actual:null,naLabel:"không áp dụng",dataReason:b.reason}));
  const vt=vtdVT(S.nam,S.thang,code,loai,DT_TFIELD[cat]);
  if(vt==null) return mkKpi(Object.assign({},base,{target:null,actual:b.actual,naLabel:"chưa có target vượt trội",
    dataReason:"Sheet TARGET chưa có Target Vượt Trội cho kỳ này"}));
  const p=prApply(M(S),vt,b.actual,Object.assign({},b.meta||{},{vuotTroi:true,targetBase:b.target,
    nguon:"Khối C. TARGET VƯỢT TRỘI của sheet TARGET"}),dtNhomOf(cat),DT_TFIELD[cat]);
  return mkKpi(Object.assign({},base,p));
}
function calcVtdCat(cat,S=ST){
  const k=sumKpi(dtUnitsOf(cat,S).map(([c,l])=>calcVtdUnitCat(c,l,cat,S)),DT_LABEL[cat]||cat,VTD_ICON[cat]);
  k.key="vt:"+cat; return k;
}
const VTD_NGOAI=["BH 1 đổi 1","BHMR","SCDV"];
const calcVtdBenTrong=S=>sumKpi([calcVtdCat("Bảo hành tại nhà",S),calcVtdCat("Bảo hành tại kho",S)],"BÊN TRONG","layers");
const calcVtdBenNgoai=S=>sumKpi(VTD_NGOAI.map(c=>calcVtdCat(c,S)),"BÊN NGOÀI","trendup");
const calcVtdTong=S=>sumKpi([calcVtdBenTrong(S),calcVtdBenNgoai(S)],"DOANH THU (4 NHÓM)","trendup");

function renderM10(){
  const S=ST, coVT=vtdThangVT(S.nam);
  const chon=(S.ky==="Năm")?monthsOf(S.nam):selMonths(S);
  const thangVT=chon.filter(m=>coVT.indexOf(m)>=0);
  if(!thangVT.length) return gopBar(S)+`<div class="card"><div class="body">${stateHTML("empty","Kỳ đang chọn chưa có Target Vượt Trội",
    coVT.length?`Target Vượt Trội chỉ có ở <b>${esc(monthsLabel(coVT))}/${S.nam}</b>. Anh chọn tháng ${coVT.join(", ")} hoặc nút <b>Quý</b> ở bộ lọc tháng phía trên để xem.`
              :`Năm ${S.nam} chưa có khối <b>C. TARGET VƯỢT TRỘI</b> trong sheet TARGET.`,"medal")}</div></div>`;
  const bt=calcVtdBenTrong(S), bn=calcVtdBenNgoai(S), tg=calcVtdTong(S);
  const banner=bannerHTML("TARGET VƯỢT TRỘI","medal",[
    bKpi("DOANH THU (4 NHÓM)",tg,"trendup",true), bKpi("BÊN TRONG",bt,"layers"), bKpi("BÊN NGOÀI",bn,"trendup")]);
  const thieu=chon.filter(m=>coVT.indexOf(m)<0);
  const ghiChu=thieu.length?`<div class="phutoggle"><span class="pt-note">Kỳ đang chọn có ${esc(monthsLabel(thieu))} chưa có Target Vượt Trội —
      tab này chỉ cộng <b>${esc(monthsLabel(thangVT))}</b> (cả target lẫn thực đạt).</span></div>`:"";

  const units=[...(showKho(S)?unitsKho(S).map(c=>[c,"kho"]):[]),...(showNha(S)?unitsNha(S).map(c=>[c,"nha"]):[])];
  const grp4=k=>`<td class="sep">${valCell(k,"target")}</td><td>${valCell(k,"actual")}</td>
    <td>${rateCell(k)}</td><td>${badge(k)}</td>`;
  const nhomCell=loai=>`<td class="l">${loai==="kho"?"Tại Kho":"Tại Nhà"}</td>`;
  const tenCell=c=>`<td class="l stick">${esc(vungOf(c).replace("Vùng ","V. "))}</td>
    <td class="l stick2"><b>${esc(tinhOf(c))}</b> <span style="color:var(--muted);font-size:10px">${esc(c)}</span></td>`;
  const totCells=`<td class="l stick">${esc(S.vung==="TONG"?"2 vùng":S.vung)}</td><td class="l stick2">TỔNG:</td><td class="l">–</td>`;
  const hd4=`<th class="sep">KPI VƯỢT TRỘI</th><th>THỰC ĐẠT</th><th>TỶ LỆ</th><th>ĐÁNH GIÁ</th>`;
  const thDV=`<th class="l stick" rowspan="2" style="vertical-align:bottom">VÙNG</th>
        <th class="l stick2" rowspan="2" style="vertical-align:bottom">TỈNH</th>
        <th class="l" rowspan="2" style="vertical-align:bottom">NHÓM</th>`;

  /* --- 1/ BÊN TRONG --- */
  const rowsIn=units.map(([c,loai])=>({c,loai,k:calcVtdUnitCat(c,loai,loai==="kho"?"Bảo hành tại kho":"Bảo hành tại nhà",S)}));
  const secIn=`<div class="card"><header><span class="ci">${ic("layers",16)}</span>
      <div><h3>1/ BÊN TRONG</h3><span class="sub">Doanh thu đơn hàng bên trong (BH tại nhà + BH tại kho) so với TARGET VƯỢT TRỘI · ${esc(kyLabel(S))}</span></div>
      <div class="hr">${infoI("Thực đạt lấy y hệt tab 5 DOANH THU. Cột KPI là <b>Target Vượt Trội</b> (khối C sheet TARGET). Với nhóm Bên trong, target vượt trội = target base. Gói bán 2025 không có target vượt trội nên không có ở tab này.")}</div></header>
    <div class="body tight"><div class="tblwrap"><table class="dt">
      <thead><tr>${thDV}<th class="g" colspan="4">${ic("layers",12)} BÊN TRONG</th></tr><tr>${hd4}</tr></thead>
      <tbody><tr class="tot">${totCells}${grp4(bt)}</tr>
        ${rowsIn.map(r=>`<tr>${tenCell(r.c)}${nhomCell(r.loai)}${grp4(r.k)}</tr>`).join("")}
      </tbody></table></div></div></div>`;

  /* --- 2/ BÊN NGOÀI --- */
  const rowsOut=units.map(([c,loai])=>{
    const d11=calcVtdUnitCat(c,loai,"BH 1 đổi 1",S), bhmr=calcVtdUnitCat(c,loai,"BHMR",S), sc=calcVtdUnitCat(c,loai,"SCDV",S);
    return {c,loai,d11,bhmr,sc,tong:sumKpi([d11,bhmr,sc],"BÊN NGOÀI","trendup")}; });
  const secOut=`<div class="card"><header><span class="ci">${ic("trendup",16)}</span>
      <div><h3>2/ BÊN NGOÀI</h3><span class="sub">BÊN NGOÀI = 1 ĐỔI 1 + BẢO HÀNH MỞ RỘNG + SỬA CHỮA KHÁCH LẺ — so với TARGET VƯỢT TRỘI</span></div>
      <div class="hr">${infoI("Chỉ gồm 3 nhóm có Target Vượt Trội. 5 dịch vụ mới (Bảo hành ủy quyền, Sửa chữa BHX/ĐMX, Gói PRO, Thu cũ đổi mới, Solar) không có target vượt trội nên không có ở tab này — TỔNG BÊN NGOÀI ở đây vì vậy có thể khác tab 5.")}</div></header>
    <div class="body tight"><div class="tblwrap"><table class="dt">
      <thead><tr>${thDV}
        <th class="g" colspan="4">${ic("trendup",12)} BÊN NGOÀI</th>
        <th class="g" colspan="4">${ic("refresh",12)} 1 ĐỔI 1</th>
        <th class="g" colspan="4">${ic("shield",12)} BẢO HÀNH MỞ RỘNG</th>
        <th class="g" colspan="4">${ic("wrench",12)} SỬA CHỮA KHÁCH LẺ</th></tr>
      <tr>${hd4.repeat(4)}</tr></thead>
      <tbody><tr class="tot">${totCells}${grp4(bn)}${grp4(calcVtdCat("BH 1 đổi 1",S))}${grp4(calcVtdCat("BHMR",S))}${grp4(calcVtdCat("SCDV",S))}</tr>
        ${rowsOut.map(r=>`<tr>${tenCell(r.c)}${nhomCell(r.loai)}${grp4(r.tong)}${grp4(r.d11)}${grp4(r.bhmr)}${grp4(r.sc)}</tr>`).join("")}
      </tbody></table></div>
      <div class="cap">Với 2 kho bảo hành tại kho, 1 đổi 1 và BHMR không áp dụng nên hiển thị “–”.</div>
    </div></div>`;

  /* --- CHI TIẾT THEO NHÓM --- */
  const rowNhom=(k,b)=>`<tr${b?' class="tot"':""}><td class="l">${b?`<b>${esc(k.name)}</b>`:esc(k.name)}</td>
      <td>${valCell(k,"target")}</td><td>${valCell(k,"actual")}</td><td>${rateCell(k)}</td><td>${badge(k)}</td></tr>`;
  const secNhom=`<div class="card"><header><span class="ci">${ic("medal",16)}</span>
      <div><h3>Chi tiết theo nhóm</h3><span class="sub">5 dòng doanh thu có Target Vượt Trội · ${esc(scopeLbl(S))} · ${esc(kyLabel(S))}</span></div></header>
    <div class="body tight"><div class="tblwrap"><table class="dt">
      <thead><tr><th class="l">NHÓM</th><th>KPI VƯỢT TRỘI</th><th>THỰC ĐẠT</th><th>TỶ LỆ</th><th>ĐÁNH GIÁ</th></tr></thead>
      <tbody>${["Bảo hành tại nhà","Bảo hành tại kho"].map(c=>rowNhom(calcVtdCat(c,S))).join("")}
        ${rowNhom(bt,true)}
        ${VTD_NGOAI.map(c=>rowNhom(calcVtdCat(c,S))).join("")}
        ${rowNhom(bn,true)}${rowNhom(tg,true)}
      </tbody></table></div></div></div>`;

  return gopBar(S) + banner + ghiChu + secIn + secOut + secNhom;
}
