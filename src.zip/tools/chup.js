#!/usr/bin/env node
/* chup.js — chụp 1 tab của github/index.html để xem giao diện.
   Dùng: node src/tools/chup.js <tab> <tháng[,tháng]> <file.png> [rộng] [vùng]        */
const {chromium}=require('playwright'); const {serve}=require('./_srv');
const [,,tab='10',ms='11',out='chup.png',w='1500',vung='TONG']=process.argv;
(async()=>{
  const s=await serve();
  const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium',args:['--no-sandbox']});
  const pg=await (await b.newContext({viewport:{width:+w,height:1000},deviceScaleFactor:1})).newPage();
  const errs=[]; pg.on('pageerror',e=>errs.push(e.message));
  await pg.goto(`http://127.0.0.1:${s.port}/github/index.html`); await pg.waitForTimeout(2500);
  await pg.evaluate(([tab,ms,vung])=>{ const a=ms.split(',').map(Number);
    Object.assign(ST,{nam:2026,ky:'Tháng',tab:+tab,vung,kho:'ALL',loai:'ALL'}); setMonths(a,true); render(); },[tab,ms,vung]);
  await pg.waitForTimeout(900);
  await pg.screenshot({path:out,fullPage:true});
  console.log('ảnh:',out,'| lỗi trang:',errs.length?errs:'không có'); await b.close(); s.close();
})();
