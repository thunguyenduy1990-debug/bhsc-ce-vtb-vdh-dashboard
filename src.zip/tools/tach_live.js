#!/usr/bin/env node
/* tach_live.js — tách index.html ĐANG CHẠY thành src/parts (+ lấy DB/VT nhúng sẵn).
   Dùng khi index.html trên web đã được sửa ở nơi khác (vd. cập nhật tab 10).
   Dùng: node src/tools/tach_live.js [github/index.html]
   Ghi: src/parts/*.js (đè), src/_live_db.json, src/_live_vt.json
   Kiểm: ráp lại phải TRÙNG TỪNG BYTE với file đầu vào.                         */
const fs=require('fs'),p=require('path');
const D=p.join(__dirname,'..'), PT=p.join(D,'parts');
const SRC=process.argv[2]||p.join(D,'..','github','index.html');
const live=fs.readFileSync(SRC,'utf8');
const M=JSON.parse(fs.readFileSync(p.join(PT,'_manifest.json'),'utf8'));
const rd=f=>fs.readFileSync(p.join(PT,f),'utf8');
const head=rd(M.head), tail=rd(M.tail);
if(!live.startsWith(head)) throw new Error('Phần đầu (01-head.html) đã đổi — cần tách tay');
let pos=head.length; const out={};
M.blocks.forEach((b,i)=>{
  const pre=M.seps[i]+b.tag;
  if(!live.startsWith(pre,pos)) throw new Error('Lệch cấu trúc ở khối '+i);
  pos+=pre.length;
  const end=live.indexOf('</script>',pos);
  const body=live.slice(pos,end);
  if(b.lib){
    const f=b.lib==='__LIB_XLSX__'?'xlsx.js':'pptxgen.js';
    if(body!==fs.readFileSync(p.join(D,'lib',f),'utf8')) throw new Error('Thư viện '+f+' đã đổi');
  } else out[b.file]=body;
  pos=end+'</script>'.length;
});
if(live.slice(pos)!==tail) throw new Error('Phần cuối (99-tail.html) đã đổi');
// 05: tách VT_EMBED và DB ra, trả lại chỗ giữ chỗ
let t=out['05-data-tail.js'];
const a='\nconst VT_EMBED = ', b=';\nconst DB = ', c=';\nDB.ky    = D';
const ia=t.indexOf(a), ib=t.indexOf(b), ic=t.indexOf(c);
if(ia!==0||ib<0||ic<0) throw new Error('Không nhận ra khối dữ liệu nhúng');
fs.writeFileSync(p.join(D,'_live_vt.json'), t.slice(a.length,ib));
fs.writeFileSync(p.join(D,'_live_db.json'), t.slice(ib+b.length,ic));
out['05-data-tail.js']=a+'__VT_EMBED__'+b+'__DB__'+t.slice(ic);
let doi=[];
for(const [f,s] of Object.entries(out)){ const cu=fs.existsSync(p.join(PT,f))?rd(f):null; if(cu!==s){doi.push(f); fs.writeFileSync(p.join(PT,f),s);} }
console.log('Đã tách', Object.keys(out).length,'khối · đổi so với bản cũ:', doi.length?doi.join(', '):'không');
