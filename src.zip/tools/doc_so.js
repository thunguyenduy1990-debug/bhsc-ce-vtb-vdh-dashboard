#!/usr/bin/env node
/* doc_so.js — mở github/index.html, chọn 1 kỳ, in bảng TỔNG HỢP 5 LĨNH VỰC đúng như web hiển thị.
   Dùng: node src/tools/doc_so.js 2026-10 [VUNG]                                      */
const {chromium}=require('playwright'); const {serve}=require('./_srv');
const [,,ky='2026-10',vung='TONG']=process.argv;
(async()=>{
  const s=await serve();
  const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium',args:['--no-sandbox']});
  const pg=await (await b.newContext({viewport:{width:1600,height:1000}})).newPage();
  await pg.goto(`http://127.0.0.1:${s.port}/github/index.html`); await pg.waitForTimeout(2500);
  const t=await pg.evaluate(([ky,vung])=>{
    const [y,m]=ky.split('-').map(Number);
    Object.assign(ST,{nam:y,thang:m,months:[m],ky:'Tháng',tab:0,vung,kho:'ALL',loai:'ALL'}); render();
    const tb=[...document.querySelectorAll('table')].find(x=>/LĨNH VỰC/i.test(x.innerText));
    return [DB.ky[ky].chuKy].concat(tb?[...tb.querySelectorAll('tr')].map(r=>[...r.cells].map(c=>c.innerText.replace(/\s+/g,' ').trim()).join(' | ')):['(không thấy bảng)']).join('\n');
  },[ky,vung]);
  console.log(t); await b.close(); s.close();
})();
